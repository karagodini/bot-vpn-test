"""
BUTTON_TEXTS – Словарь, содержащий текстовые метки для кнопок интерфейса у администратора бота.
"work_with_servers" : "🌏 Менеджер серверов",
"restart_bot": "🔄 Перезагрузить бота", и т.д
"""
BUTTON_TEXTS = {
    "broadcast": "📢 Рассылка уведомлений",
    "send_message": "📝 Отправить сообщение",
    "add_promo_code": "➕ Добавить промокод",
    "delete_promo_code": "➖ Удалить промокод",
    "delete_clients": "🗑 Удалить просроченных клиентов",
    "statistics": "📊 Статистика",
    "backup": "💾 Бекап базы данных",
    "restart_bot": "🔄 Перезагрузить бота",
    "cancel": "❌ Отмена",
    "confirm_delete": "✅ Да, удалить",
    "no_delete": "❌ Нет, отменить",
    "work_with_servers" : "🌏 Менеджер серверов",
    "add_server": "➕ Добавить сервер",
    "show_servers_info": "📋 Показать все данные о серверах",
    "change_server_ids": "🔄 Изменить список серверов",
    "edit_server": "✏️ Редактировать сервер",
    "d_server": "🗑 Удалить сервер",
    "change_group_server" : "🔄 Сменить кластер серверов",
    "cluster_delete": "🗑 Удалить кластер серверов",
    "referrals": "Рефералы",
}
